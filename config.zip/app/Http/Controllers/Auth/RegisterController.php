<?php

namespace App\Http\Controllers\Auth;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class RegisterController extends Controller
{
    // ----------- [ Return view] -----------
    public function index()
    {
        return view('auth.register');
    }


    // ----------- [ Logic to Register the user] -----------
    public function store(Request $request)
    {

        // ----------- [ Form validate ] -----------
        $this->validate($request, [
            'fullName'              =>   'required|string|max:20',
            'email'             =>      'required|email',
            'phone'             =>      'required|numeric|min:10',
            'password'          =>      'required|alpha_num|min:6|confirmed',

        ]);

        User::create([
            'name' => $request->fullName,
            'email' => $request->email,
            'phone' => $request->phone,
            'password' => Hash::make($request->password),
        ]);

        Auth::attempt($request->only('email', 'password'));
        // auth()->attempt($request->only('email', 'password'));
    }
}