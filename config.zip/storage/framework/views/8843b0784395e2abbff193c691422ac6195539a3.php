

<?php $__env->startSection('content'); ?>
<h1>welcome dashboard</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-newproject\laravel-app\resources\views/dashboard.blade.php ENDPATH**/ ?>